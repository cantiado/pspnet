# PSPNet > version1
https://universe.roboflow.com/nathaniels-dashboard/pspnet

Provided by a Roboflow user
License: CC BY 4.0

